import java.util.Scanner;
import java.util.HashMap;
import java.util.Comparator;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
public class BSCS {
    String name,number;
    int formno,fsc,test,roll;
    HashMap<String,Integer>details=new HashMap<>();
    HashMap<String,Integer>form=new HashMap<>();
    HashMap<String,Integer>entry=new HashMap<>();
    HashMap<String,Integer>score=new HashMap<>();
    HashMap<String , Double>finalmerit=new HashMap<>();

    public void getdetails(String name,int fsc)
    {
        if(fsc>=50) {
            details.put(name, fsc);
            System.out.println(details);
        }
    }
    public void getform(String number,int formno)
    {

            form.put(number, formno);
            System.out.println(form);
    }
    public void display()
    {
        for(String s:form.keySet())
        {
            System.out.println("The form name is:"+s);
        }
        for(Integer b:form.values())
        {
            System.out.println("The form number is:"+b);
        }
    }
    public void Entry()
    {
        for(String j: details.keySet())
        {
            System.out.println("The candidate eligible for the entry test is:"+j);
        }
    }
    public void roll(String w,int roll)
    {
            entry.put(w, roll);
            System.out.println(entry);
    }
    public void getscore(String name,int test)
    {
            score.put(name,test);
            System.out.println(score);
    }
    public void calculateFinalMerit() {
        for (String name : details.keySet()) {
            int fscMarks = details.get(name);
            int testMarks = score.getOrDefault(name, 0);
            double merit = (fscMarks * 60 / 100) + (testMarks * 40 / 100);
            finalmerit.put(name, merit);
        }
    }
        public void getMeritlist()
    {
            List<Map.Entry<String, Double>> sortedList = new ArrayList<>(finalmerit.entrySet());
            Collections.sort(sortedList, new Comparator<Map.Entry<String, Double>>() {
                public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                    return Double.compare(o2.getValue(), o1.getValue());
                }
            });

            System.out.println("-----------Merit list for BSCS students----------");
        int count=0;
            for (Map.Entry<String, Double> entry : sortedList) {
                if(count>=5){
                    break;
                }

                System.out.println("Candidate: " + entry.getKey() + ", Final Merit: " + entry.getValue());
count++;
            }
        }




    public static void main(String args[]) {
        BSCS s1 = new BSCS();
        String x, y;
        int m, a, f, k;
        Scanner kb = new Scanner(System.in);
        //in the program it was said that display top 200 candidates in the merit list but for check if the program is correct i am using loop of 5 students
for(int i=0;i<=5;i++)
{
        System.out.println("Enter your name:");
        x = kb.next();
        System.out.println("Enter your fsc marks:");
        m = kb.nextInt();
        s1.getdetails(x, m);
        System.out.println("Enter the form name");
        y = kb.next();
        System.out.println("Enter the form number:");
        a = kb.nextInt();
        s1.getform(y, a);
        s1.display();
        s1.Entry();
        System.out.println("Enter your roll number:");
        f = kb.nextInt();
        s1.roll(x, f);
        System.out.println("Enter your test marks:");
        k = kb.nextInt();
        s1.getscore(x, k);
        s1.calculateFinalMerit();
    }
          s1.getMeritlist();


        }

        }


