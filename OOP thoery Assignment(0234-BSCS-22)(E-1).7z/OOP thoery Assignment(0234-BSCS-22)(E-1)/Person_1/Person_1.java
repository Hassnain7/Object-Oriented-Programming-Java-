public class Person_1 {
    String name,date,month,year;
    public Person_1(String name,String date,String month,String year)
    {
        this.name=name;
        this.date=date;
        this.month=month;
        this.year=year;
    }
    public String getName()
    {
        return name;
    }
    public String getDate()
    {
        return date;
    }
    public String getMonth()
    {
        return month;
    }
    public String getYear()
    {
        return year;
    }
    public String getage()
    {
        return name+"-"+date+"-"+month+"-"+year;
    }

    public static void main(String args[])
    {
        Person_1 p1=new Person_1("ahmed","01","10","1974");
        Person_1 p2=new Person_1("ali","01","11","1976");
        System.out.println(p1.getage());
        System.out.println(p2.getage());
        if(Integer.parseInt(p1.getDate())<Integer.parseInt(p2.getDate())||Integer.parseInt(p1.getMonth())<Integer.parseInt(p2.getMonth())||Integer.parseInt(p1.getYear())<Integer.parseInt(p2.getYear()))
        {
            System.out.println(p1.getName()+" is elder than "+p2.getName());
        }
        else
        {
            System.out.println(p2.getName()+" is elder than "+p1.getName());
        }
        if(p1.getage()!=p2.getage())
        {
            System.out.println("Age difference:");
            int difference_days=Integer.parseInt(p2.getDate()) -Integer.parseInt( p1.getDate());
            System.out.println(difference_days+"days");
            int difference_month=Integer.parseInt(p2.getMonth())-Integer.parseInt(p1.getMonth());
            System.out.println(difference_month+"months");
            int difference_year=Integer.parseInt(p2.getYear())-Integer.parseInt(p1.getYear());
            System.out.println(difference_year+"year");
        }
    }
}
